//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
#include "RecordCtrl.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void CALLBACK my_on_record_callback( int n_lp_instance,char* ip,int channel_id,  char* name,char *memo)
{
    AnsiString msg;
    msg.sprintf("ip = %s    channel_id = %d   name = %s   memo = %s",ip,channel_id,name,memo);
    Form1->Memo1->Lines->Add(msg);
}

void __fastcall TForm1::Button1Click(TObject *Sender)
{
     if(ky_record_init_server(Edit1->Text.c_str(),Edit2->Text.ToInt()) == 0)
     {
         Memo1->Lines->Add("ky_record_init_server ok");
     }
     else
     {
         Memo1->Lines->Add("ky_record_init_server fail");
     }
     ky_record_set_alarm_callback((int)my_on_record_callback,(int)this);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
     int i = ky_record_get_devlist_count();

     AnsiString msg;
     msg.sprintf("count = %d",i);
     Memo1->Lines->Add(msg);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
    int ret = 0;
    int count = 0;
    count = ky_record_get_devlist_count();

    AnsiString msg;
    msg.sprintf("count = %d",count);
    Memo1->Lines->Add(msg);

    ky_record_dev_item *dev_items = new ky_record_dev_item[count];
    ret = ky_record_get_devlist(dev_items, count);
    msg.sprintf("ret = %d",ret);
    Memo1->Lines->Add(msg);

    for(int i = 0;i<count;i++)
    {
        msg.sprintf("index = %d   ip = %s   channelcount = %d   memo = %s",dev_items[i].index,dev_items[i].ip,dev_items[i].channelcount,dev_items[i].memo);
        Memo1->Lines->Add(msg);
    }
    delete dev_items;
}
//---------------------------------------------------------------------------





void __fastcall TForm1::Button4Click(TObject *Sender)
{
    ky_record_begin_record(Edit3->Text.c_str(),Edit4->Text.ToInt(),Edit5->Text.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
    ky_record_stop_record(Edit3->Text.c_str(),Edit4->Text.ToInt());
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button6Click(TObject *Sender)
{
    ky_record_begin_recive_msg();    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button7Click(TObject *Sender)
{
    ky_record_stop_recive_msg();    
}
//---------------------------------------------------------------------------

